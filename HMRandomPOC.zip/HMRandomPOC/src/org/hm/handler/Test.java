package org.hm.handler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hm.bean.RandomVO;

public class Test {
	public static void main(String arg[]){
		  
		  GenerateRandom rando = new GenerateRandom();
		  RandomVO random1=new RandomVO(1,"103,205,325,452,225");		

			List<RandomVO> listOfRandomValues = new ArrayList<RandomVO>();
			listOfRandomValues.add(random1);
		 	  
			int id;
			int data=0;
			String numbers = null;
			for(RandomVO getData : listOfRandomValues){
				 id = getData.getPosition();
				 numbers = getData.getRandomNums();
			}
				int i=1;
				List<Integer> li = new ArrayList<Integer>();
				ArrayList<Integer> position = new ArrayList<Integer>();
				for(String randomNum: numbers.split(",",0)){
				
				li.add( Integer.valueOf(randomNum));
				i++;
						
				position.add(li.indexOf(Integer.valueOf(randomNum)));
				
				}
				Collections.sort(li);
				System.out.println("Input Position of value ");
				System.out.println(position);
				System.out.println("Input Normal Data: ");
				System.out.println(li);

				GenerateRandom convertData = new GenerateRandom();
				for(int x=0; x<25; x++){
					long startTime = System.currentTimeMillis();
				 List<Integer>  getRandomData = convertData.getRandomData(li);
				 long endTime = System.currentTimeMillis();
				  System.out.println("Seconds take for execution is:"+(endTime-startTime)/1000);
					System.out.println("Output Data");
					System.out.println(position);
			//	 System.out.println("Output Random Data");
				 System.out.println(getRandomData);
				}
	  }}
