package org.hm.handler;

public class ThreadExecution {


    public static void main(String[] args) {
    	ThreadExecution me = new ThreadExecution();
        long startTime = System.currentTimeMillis();
        float v = me.callSlowMethod();
        long endTime = System.currentTimeMillis();
        System.out.println("Seconds take for execution is:"+(endTime-startTime)/1000);
    }
    /* Simulates a time consuming method */
    private float callSlowMethod() {
        float j=0;
        for(long i=0;i<5000000000L;i++) {
            j = i*i;
        }
        return j;
    }
}