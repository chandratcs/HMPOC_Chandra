package org.hm.bean;

import java.util.List;

public class RandomVO{
	
	int position;
	String randomNums;	
	
	public RandomVO(int position, String randomNums) {
		super();
		this.position = position;
		this.randomNums = randomNums;
	}
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public String getRandomNums() {
		return randomNums;
	}
	public void setrandomNums(String randomNums) {
		this.randomNums = randomNums;
	}	
	
}